<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
    </head>

    <body>
      początek pliku
      <?php //jeżeli ściweżka będzie błędna, a dodamy @, to strona będzie dalej nam działać
        include './dolaczanie/name.php';
        include_once './dolaczanie/name.php'; //aby się nie powtarzało

        require './dolaczanie/name.php'; //jeżeli wystąpi b łąd, cała reszta kodu nie zadziała
        require_once './dolaczanie/name.php'; //aby się nie powtarzało 
      ?>
      koniec pliku
    </body>
  </html>
