<?php
  echo "<hr>mam na imię Janusz<hr>";
?>
